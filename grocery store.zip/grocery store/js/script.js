let navbar = document.querySelector('.header .flex .navbar');

document.querySelector('#menu-btn').onclick = () =>{
   navbar.classList.toggle('active');
   profile.classList.remove('active');
}

let profile = document.querySelector('.header .flex .profile');

document.querySelector('#user-btn').onclick = () =>{
   profile.classList.toggle('active');
   navbar.classList.remove('active');
}

window.onscroll = () =>{
   profile.classList.remove('active');
   navbar.classList.remove('active');
}

document.addEventListener('DOMContentLoaded', function() {
   const accountBtn = document.getElementById('account-btn');
   const profileSection = document.getElementById('profile-section');

   accountBtn.addEventListener('click', function() {
       if (profileSection.style.display === 'none' || profileSection.style.display === '') {
           profileSection.style.display = 'block';
       } else {
           profileSection.style.display = 'none';
       }
   });
});




