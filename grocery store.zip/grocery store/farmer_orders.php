<?php

@include 'config.php';

session_start();

$farmer_id = $_SESSION['farmer_id'];

if(!isset($farmer_id)){
   header('location:login.php');
};

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   $delete_orders = $conn->prepare("DELETE FROM `orders` WHERE id = ?");
   $delete_orders->execute([$delete_id]);
   header('location:farmer_orders.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Orders</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <!-- <link rel="stylesheet" href="css/farmer_style.css"> -->

</head>
<body>
   <style>
      /* Global Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Verdana', sans-serif;
    background-color: #e8f5e9;
    color: #2d6a4f;
}

/* Header */
header {
    background-color: #388e3c;
    color: #fff;
    padding: 20px;
    text-align: center;
}

header a {
    color: #fff;
    text-decoration: none;
    font-size: 1.2rem;
    margin: 0 20px;
}

header a:hover {
    color: #fbc02d;
}

/* Orders Section */
.placed-orders {
    max-width: 1000px;
    margin: 50px auto;
    padding: 30px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.placed-orders .title {
    font-size: 2rem;
    color: #388e3c;
    text-align: center;
    margin-bottom: 30px;
}

/* Box Container */
.box-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); /* Adjust the box size */
    gap: 20px; /* Smaller gap between boxes */
}

/* Individual Order Box */
.box {
    background-color: #ffffff;
    border: 2px solid #388e3c;
    border-radius: 8px;
    padding: 15px; /* Reduced padding */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    font-size: 1rem; /* Adjusted font size */
}

.box p {
    font-size: 1rem; /* Reduced font size */
    margin: 8px 0;
}

.box p span {
    font-weight: bold;
}

/* Flex Button */
.flex-btn .delete-btn {
    background-color: #f44336;
    color: #fff;
    padding: 8px 16px; /* Reduced padding */
    font-size: 1rem; /* Smaller font size */
    border-radius: 8px;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.flex-btn .delete-btn:hover {
    background-color: #c62828;
}

/* Responsive Design */
@media (max-width: 768px) {
    .placed-orders .title {
        font-size: 1.8rem;
    }

    .box {
        padding: 12px; /* Reduced padding for smaller screens */
    }
}

   </style>
   
<?php include 'farmer_header.php'; ?>

<section class="placed-orders">

   <h1 class="title">Placed Orders</h1>

   <div class="box-container">

      <?php
         $select_orders = $conn->prepare("SELECT * FROM `orders`");
         $select_orders->execute();
         if($select_orders->rowCount() > 0){
            while($fetch_orders = $select_orders->fetch(PDO::FETCH_ASSOC)){
      ?>
      <div class="box">
         <p> User id : <span><?= $fetch_orders['user_id']; ?></span> </p>
         <p> Placed on : <span><?= $fetch_orders['placed_on']; ?></span> </p>
         <p> Name : <span><?= $fetch_orders['name']; ?></span> </p>
         <p> Email : <span><?= $fetch_orders['email']; ?></span> </p>
         <p> Number : <span><?= $fetch_orders['number']; ?></span> </p>
         <p> Address : <span><?= $fetch_orders['address']; ?></span> </p>
         <p> Total products : <span><?= $fetch_orders['total_products']; ?></span> </p>
         <p> Total price : <span>₹<?= $fetch_orders['total_price']; ?>/-</span> </p>
         <p> Payment method : <span><?= $fetch_orders['method']; ?></span> </p>
         <p> Payment status : <span><?= $fetch_orders['payment_status']; ?></span> </p>
         <div class="flex-btn">
            <a href="farmer_orders.php?delete=<?= $fetch_orders['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this order?');">Delete</a>
         </div>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no orders placed yet!</p>';
      }
      ?>

   </div>

</section>

<script src="js/script.js"></script>

</body>
</html>