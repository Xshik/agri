<?php

@include 'config.php';

if (isset($_POST['submit'])) {

    // Sanitize and validate inputs
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $pass = filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
    $cpass = filter_var($_POST['cpass'], FILTER_SANITIZE_STRING);
    $image = filter_var($_FILES['image']['name'], FILTER_SANITIZE_STRING);
    $user_type = filter_var($_POST['user_type'], FILTER_SANITIZE_STRING);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message[] = 'Invalid email format!';
    }

    // Validate password length and match
    if (strlen($pass) < 6) {
        $message[] = 'Password must be at least 6 characters long!';
    } elseif ($pass !== $cpass) {
        $message[] = 'Confirm password does not match!';
    }

    // Hash the passwords
    $pass_hash = md5($pass);

    // Validate image file type and size
    $allowed_file_types = ['jpg', 'jpeg', 'png'];
    $image_extension = pathinfo($image, PATHINFO_EXTENSION);
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_folder = 'uploaded_img/' . $image;

    if (!in_array($image_extension, $allowed_file_types)) {
        $message[] = 'Only JPG, JPEG, and PNG files are allowed!';
    }

    if ($image_size > 2000000) {
        $message[] = 'Image size is too large!';
    }

    // Validate user type
    $valid_user_types = ['user', 'admin', 'farmer'];
    if (!in_array($user_type, $valid_user_types)) {
        $user_type = 'user'; // Default to 'user' if invalid
    }

    // Check if email already exists
    $select = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
    $select->execute([$email]);

    if ($select->rowCount() > 0) {
        $message[] = 'User email already exists!';
    } else {
        // Proceed with registration if there are no validation errors
        if (empty($message)) {
            $insert = $conn->prepare("INSERT INTO `users`(name, email, password, image, user_type) VALUES(?,?,?,?,?)");
            $insert->execute([$name, $email, $pass_hash, $image, $user_type]);

            if ($insert) {
                move_uploaded_file($image_tmp_name, $image_folder);
                $message[] = 'Registered successfully!';
                header('location:login.php');
            } else {
                $message[] = 'Registration failed! Please try again.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
  <link rel="stylesheet" href="css/reg.css">
</head>
<body>

<?php
if (isset($message)) {
    foreach ($message as $msg) {
        echo '
        <div class="message">
            <span>' . $msg . '</span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
        </div>
        ';
    }
}
?>
<div class="container">
<section class="form-container">
    <form action="" enctype="multipart/form-data" method="POST">
        <h2>Agribridge</h2>
        <h3>Register Now</h3>
        <input type="text" name="name" class="box" placeholder="Enter your name" required>
        <input type="email" name="email" class="box" placeholder="Enter your email" required>
        <input type="password" name="pass" class="box" placeholder="Enter your password" required>
        <input type="password" name="cpass" class="box" placeholder="Confirm your password" required>
        <input type="file" name="image" class="box" required accept="image/jpg, image/jpeg, image/png">
        <select name="user_type" class="box" required>
            <option value="user" selected>User</option>
            <option value="admin">Admin</option>
            <option value="farmer">Farmer</option>
        </select>
        <input type="submit" value="Register Now" class="btn" name="submit">
        <p>Already have an account? <a href="login.php">Login now</a></p>
    </form>
</section>
</div>
</body>
</html>
